<?php

use Illuminate\Support\Facades\Facade;

return [
    /*
    |--------------------------------------------------------------------------
    | Revix Version
    |--------------------------------------------------------------------------
    | This value is set when creating a Revix release. You should not
    | change this value. Otherwise you may face issues with the theme.
    |
    */

    'version' => '2.0',
    'build' => 'Y25R2C06B',
];
