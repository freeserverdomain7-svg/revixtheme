import styled from 'styled-components/macro';
import tw from 'twin.macro';

export const ContentContainer = styled.div`
    ${tw`flex pt-16 lg:pl-[250px] pr-1`}
`;